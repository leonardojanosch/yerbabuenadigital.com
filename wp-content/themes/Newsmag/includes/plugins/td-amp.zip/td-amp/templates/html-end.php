<?php
/**
 * HTML end template part.
 *
 */
?>

<?php do_action( 'amp_post_template_footer', $this ); ?>

</div><!-- close td-outer-wrap -->

</body>
</html>
